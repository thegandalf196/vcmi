Stronghold Guild Ridge Swap for VCMI

Install the stronghold-mage-guild-ridge-swap folder in VCMI Mods and enable it.
Mage Guild levels 1-5 are on the former Hall of Valhalla ridge. Hall of Valhalla is on the former mage ridge. Levels 3 and 4 repeat a middle floor course from the original level-2 art, and level 5 uses the original level-3 tower. The guild sits on the mountain at its new location; its old right rock shelf is trimmed and the road edge is blended with the underlying mountain. Selection masks and town-hall icons are included.

The package has been structurally validated, but an in-game VCMI check is still needed for build flow, selection, and overlap.
