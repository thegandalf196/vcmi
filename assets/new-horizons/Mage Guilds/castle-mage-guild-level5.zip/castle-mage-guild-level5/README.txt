Castle Mage Guild Level 5 for VCMI

Install castle-mage-guild-level5 in your VCMI Mods folder.

Levels 1-4 retain their original sprites and positions. The new level 5 uses the original level-4 tower with one repeated window course below its original copper roof. All 11 source animation frames are retained and the lower torch animation moves with the tower base. Its y-position is adjusted to retain the original baseline. The original level-4 selection masks are extended for the added course. The original level-4 campaign icon and town-hall icon are reused for level 5.

The package has local structural checks, but still needs an in-game VCMI check for construction, selection, animation, and overlap.
