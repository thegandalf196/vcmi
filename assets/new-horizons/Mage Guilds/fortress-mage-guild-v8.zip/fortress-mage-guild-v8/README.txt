Fortress Mage Guild V8 for VCMI

Install: copy the fortress-mage-guild-v8 folder into your VCMI Mods folder, then enable it in the VCMI Launcher. Alternatively extract the ZIP into Mods.

Adds buildable Fortress Mage Guild levels 4 and 5. The town animations use the approved v8 art and 21 synchronized flame frames. The hall icons are static and reuse the original level-3 hall scenery with updated windows. Original level-3 selection masks and campaign bonus icon are reused because the building silhouette is unchanged. All other Fortress assets come from the base game.

This package has been checked structurally, but still needs a VCMI in-game test for placement, animation, build flow, and spell screens.
