# Fortress Mage Guild

VCMI mod targeting version 1.7.5 or newer. Remakes all five Fortress Mage Guild
levels in one consistent style and enables levels 4 and 5.

Version 0.9.0 preserves the approved levels 1–4 exactly and rebuilds level 5
directly from approved level 4, adding one compact tier in the same dark,
grainy CGI style. Level 5 remains 223 pixels tall; level 4 is 210 pixels tall.
The approved set is archived separately in approved-levels-1-4.
The original-derived version 0.6.0 artwork remains saved separately.
The art basis follows the original game sprites: their CGI shading,
bitmap texture appearance and soft pixel detail, rather than the illustrated remakes.
Levels 4–5 extend that original appearance with added tiers. Levels 1–3 preserve
the original appearance with entrance stair corrections.
The centered wooden stairs reach the lowest purple triangle directly.
Levels 1–2 follow the original modest timber roof shapes.

Copy this entire folder into your VCMI `Mods` directory, then enable **Fortress
Mage Guild** in the launcher and start a new game.

All five buildings include native DEF art, gold hover
outlines, interaction masks, build-menu thumbnails, and campaign bonus pictures.
Levels 3–5 have 21-frame torch light flicker; levels 1–2 have static torch bowls.
Level 5 uses a plain bronze/yellow roof with no gem ornament.

Configuration is in `content/config/fortress-mage-guild.json`.
Level 4 requires level 3; level 5 requires level 4. Each costs 1,000 gold,
5 wood, 5 ore, and 7/8 of each rare resource respectively.
Levels 1–3 retain their original costs and prerequisites; their artwork is overridden.

The binary assets and configuration fields have been checked locally.
This package has not been tested in a live VCMI engine session.

Start a new Fortress map, build through level 5, inspect the town hover/click
behavior, open the guild to verify the new scroll rows, then save and reload.
Maps that explicitly forbid the upgrades will retain those restrictions.

Other mods replacing Fortress's buildings, hall slots or HALLFORT animation may
need a compatibility patch. Remove this mod folder to uninstall; use separate
save games for testing.
